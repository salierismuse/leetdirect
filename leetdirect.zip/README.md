# leetdirect

basic firefox browser extension that allows you to set websites that will redirect you automatically to a leetcode easy. if you have time to doomscroll, you've got five minutes for an easy!


get_problems.py: python script that by default fetches all easys from leetcode's website and provides the links. dumps into a txt file. this can obviously be modified to match whatever specifications you may want it to have if you'd like to change it. it then converts it into a js array and sends that to problems.js to be accessed and used by background.js

